const { delay } = require("@whiskeysockets/baileys");

// Objeto para armazenar dados de anti-spam
const spamRecords = new Map();

// Criando um objeto para exportar
const groupManagement = {
  // Função para banir usuários
  banUser: async (sock, jid, users) => {
    try {
      if (!jid.endsWith('@g.us')) return { error: "Este comando só funciona em grupos" };

      const metadata = await sock.groupMetadata(jid);
      const participants = metadata.participants.map(p => p.id);
      const botJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';
      const isAdmin = metadata.participants.some(p => p.id === botJid && p.admin);

      // Logs para depuração
      console.log('[DEBUG] Usuários recebidos para banir:', users);
      console.log('[DEBUG] Participantes do grupo:', participants);

      if (!isAdmin) return { error: "O bot não é administrador" };

      const results = [];
      for (const user of users) {
        const formattedUser = user.replace(/\D/g, '') + '@s.whatsapp.net';

        if (!participants.includes(formattedUser)) {
          results.push({ user: formattedUser, error: "Usuário não está no grupo" });
          continue;
        }

        try {
          await sock.groupParticipantsUpdate(jid, [formattedUser], 'remove');
          results.push({ user: formattedUser, success: true });
        } catch (error) {
          results.push({ user: formattedUser, error: error.message });
        }
      }

      // Verifica se houve algum sucesso
      const hasSuccess = results.some(r => r.success);
      return { 
        results,
        message: hasSuccess ? "Usuário banido com sucesso" : "Falha ao banir usuário(s)"
      };
    } catch (error) {
      console.error("Erro detalhado:", error);
      return { error: "Erro interno: " + error.message };
    }
  },

  // Função para deletar mensagens
  deleteMessage: async (sock, jid, messageKey) => {
    try {
      await sock.sendMessage(jid, { delete: messageKey });
      return { success: true };
    } catch (error) {
      console.error("Erro ao deletar mensagem:", error);
      return { error: error.message };
    }
  },

  // Sistema Anti Spam
  antiSpam: async function(sock, msg) {
    try {
      const sender = msg.key.participant || msg.key.remoteJid;
      const now = Date.now();

      if (spamRecords.has(sender)) {
        const record = spamRecords.get(sender);
        if (now - record.lastMessage < 3000) { // 3 segundos
          record.count++;
          if (record.count >= 3) {
            await groupManagement.banUser(sock, msg.key.remoteJid, [sender]);
            return { action: 'banned' };
          }
        } else {
          record.count = 1;
        }
        record.lastMessage = now;
      } else {
        spamRecords.set(sender, { count: 1, lastMessage: now });
      }

      return { action: 'monitored' };
    } catch (error) {
      console.error("Erro no anti-spam:", error);
      return { error: error.message };
    }
  },

  // Marcar usuários
  mentionUsers: async (sock, jid, users, message) => {
    try {
      const mentionedJid = users.map(user => user.replace(/\D/g, '') + '@s.whatsapp.net');
      await sock.sendMessage(jid, {
        text: `${message}\n${mentionedJid.map(u => `@${u.split('@')[0]}`).join(' ')}`,
        mentions: mentionedJid
      });
      return { success: true };
    } catch (error) {
      console.error("Erro ao marcar usuários:", error);
      return { error: error.message };
    }
  },

  // Limpar chat
  clearChat: async (sock, jid) => {
    try {
      await sock.chatModify({ delete: true }, jid);
      return { success: true };
    } catch (error) {
      console.error("Erro ao limpar chat:", error);
      return { error: error.message };
    }
  },

  // Mensagens aleatórias
  randomMessages: (sock, jid, messages, interval) => {
    const sendRandom = async () => {
      const randomIndex = Math.floor(Math.random() * messages.length);
      await sock.sendMessage(jid, { text: messages[randomIndex] });
    };

    const intervalId = setInterval(sendRandom, interval * 60000);
    return intervalId; // Para poder parar o intervalo posteriormente
  },

  // Função Anti-Link
  antiLink: async (sock, msg) => {
    try {
      const jid = msg.key.remoteJid;
      const sender = msg.key.participant || msg.key.remoteJid;
      const message = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';

      // Regex para detectar links (http, https, www, .com, .net, etc)
      const linkRegex = /(https?:\/\/|www\.|\.com|\.net|\.org|\.io|\.me|\.co)[^\s]*/gi;

      if (!linkRegex.test(message)) return { linkFound: false };

      // Verificar se é um grupo
      if (!jid.endsWith('@g.us')) return { linkFound: false };

      // Obter metadados do grupo
      const metadata = await sock.groupMetadata(jid);
      const isAdmin = metadata.participants.find(p => p.id === sender)?.admin;

      // Se o remetente não for admin, apagar a mensagem e enviar aviso
      if (!isAdmin) {
        await sock.sendMessage(jid, { 
          delete: msg.key 
        });

        await sock.sendMessage(
          jid,
          { 
            text: `⚠️ @${sender.split('@')[0]}, *links são proibidos!*\n\nSiga as regras do grupo:\n1. Sem links\n2. Respeite todos\n3. Sem spam`,
            mentions: [sender]
          },
          { quoted: msg }
        );

        return { linkFound: true, actionTaken: true };
      }

      return { linkFound: true, actionTaken: false };
    } catch (error) {
      console.error("Erro no anti-link:", error);
      return { error: error.message };
    }
  }
};

module.exports = groupManagement;